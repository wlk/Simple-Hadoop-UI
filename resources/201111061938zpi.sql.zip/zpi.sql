-- phpMyAdmin SQL Dump
-- version 3.3.2deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Czas wygenerowania: 06 Lis 2011, 21:58
-- Wersja serwera: 5.1.41
-- Wersja PHP: 5.3.2-1ubuntu4.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Baza danych: `zpi`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `algorithms`
--

CREATE TABLE IF NOT EXISTS `algorithms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `schema` text,
  `parameters` text,
  `jar_file_location` text,
  `short_name` varchar(100) DEFAULT NULL,
  `long_name` text,
  `is_public` tinyint(1) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `removed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Zrzut danych tabeli `algorithms`
--

INSERT INTO `algorithms` (`id`, `schema`, `parameters`, `jar_file_location`, `short_name`, `long_name`, `is_public`, `user_id`, `removed_at`) VALUES
(1, '', 'test', 'location', 'Algorytm 1', 'Algorytm 1 d?ugi opis', 1, 1, NULL),
(2, 'test', 'test', 'location', 'Algorytm 2', 'Algorytm 2 - d?uga nazwa', 0, 1, NULL),
(5, 'int;int', 'string;int', '/home/wojtek/dijkstra.jar', 'bfs', 'breadth first search', 1, 1, NULL);

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `networks`
--

CREATE TABLE IF NOT EXISTS `networks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  `schema` text,
  `network_file_location` text,
  `is_valid` tinyint(1) DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `delimiter` varchar(30) DEFAULT NULL,
  `removed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1000 ;

--
-- Zrzut danych tabeli `networks`
--

INSERT INTO `networks` (`id`, `name`, `schema`, `network_file_location`, `is_valid`, `is_public`, `user_id`, `delimiter`, `removed_at`) VALUES
(999, 'name1', 'test', 'test', 0, 0, 0, '', NULL),
(1, 'w1', 'int;int', 'hdfs://p08/user/wojtek/w1', 1, 1, 1, ' ', NULL);

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `queue`
--

CREATE TABLE IF NOT EXISTS `queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `algorithm_id` int(11) DEFAULT NULL,
  `network_id` int(11) DEFAULT NULL,
  `output_file_location` text CHARACTER SET latin1,
  `started_at` date DEFAULT NULL,
  `ended_at` date DEFAULT NULL,
  `parameters` text CHARACTER SET latin1,
  `progress` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `status` varchar(30) COLLATE utf8_polish_ci DEFAULT NULL,
  `hadoop_job_id` varchar(30) COLLATE utf8_polish_ci DEFAULT NULL,
  `removed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci AUTO_INCREMENT=2 ;

--
-- Zrzut danych tabeli `queue`
--

INSERT INTO `queue` (`id`, `algorithm_id`, `network_id`, `output_file_location`, `started_at`, `ended_at`, `parameters`, `progress`, `user_id`, `status`, `hadoop_job_id`, `removed_at`) VALUES
(1, 5, 1, 'hdfs://p08/user/wojtek/dijkstra1res', NULL, NULL, '4', 0, 1, '', '', NULL);

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  `is_admin` tinyint(1) DEFAULT NULL,
  `removed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Zrzut danych tabeli `users`
--

INSERT INTO `users` (`id`, `name`, `password`, `is_admin`, `removed_at`) VALUES
(1, '', '', 1, NULL),
(2, 'marek', 'marek', 1, NULL);
